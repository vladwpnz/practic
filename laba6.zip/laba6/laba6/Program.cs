﻿using System;
using System.Text;

namespace Laba6
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.Write("Введите количество елементов массива: \t");                      // 8. Написати метод зміни довжини масиву на вказану довжину.                              
            int elm = int.Parse(Console.ReadLine());                              
            int[] myArray = new int[elm];



           for (int i = 0; i < myArray.Length; i++)
            {
                Console.WriteLine($"\nВведите елемент масива под индексом {i} \t"); 
                myArray[i] = int.Parse(Console.ReadLine());
            }


            Console.WriteLine("\nВывод масива:");

            for (int i = myArray.Length - 1; i >= 0; i--)                                       // 7. Реалізувати метод, що буде масив повертати задом навпаки (Використання Array.Reverse() заборонено!)
            {
                Console.WriteLine(myArray[i]);
            }





            Console.WriteLine("\nВведите число\t");
            int n = int.Parse(Console.ReadLine());                                              // 1. Виводить на екран введене число з клавіатури в зворотному порядку (1234->4321)
            
            string chislo = n.ToString();
            
            char[] mystr = chislo.ToCharArray();

            for (int i = mystr.Length; i > 0; i--)
                Console.Write(mystr[i - 1]);




            Console.WriteLine("\nВведите слово\t");                                             // 2. Виводить будь-яку строку в зворотному порядку (АБВ->ВБА)

            string str = Console.ReadLine();

            for (int i = str.Length - 1; i >= 0; i--)
            {
                Console.Write(str[i]);
            }


        
               
            double j;
            string str1;
            

            Console.WriteLine("\nВведите дробове число:\t");                                      //3 Дробові числа виводяться в зворотному порядку і ціла частина і дробова (123.456->321.654)


            str1 = Console.ReadLine();
            j = double.Parse(str1);
            Reverse(j);
                
            
            static double Reverse(double j)
            {                              
                string inpt = j.ToString();
                char[] Myarray = inpt.ToCharArray();
                for (int i = 0; i < Myarray.Length / 2; i++)
                {
                    char tmp = Myarray[i];
                    Myarray[i] = Myarray[Myarray.Length - i - 1];
                    Myarray[Myarray.Length - i - 1] = tmp;
                }
                string output = new string(Myarray);
                Console.WriteLine(output);
                return j;
            }




   

        }
    }
}
